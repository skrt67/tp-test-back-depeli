<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\AuthorController;
use App\Http\Controllers\BookController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\SearchController;
use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

Route::get('/test', function () {
    return view('test');
});

Route::get('/greeting/{name?}', function (string $name = 'Guest') {
    return view('greeting', ['name' => $name]);
});

Route::group([
    'middleware' => 'auth',
], function () {
    Route::get('/books', [BookController::class, 'index'])->name('book.index')->withoutMiddleware('auth');
    Route::get('/books/create', [BookController::class, 'create'])->name('book.create');
    Route::post('/books', [BookController::class, 'store'])->name('book.store');
    Route::get('/books/{book}', [BookController::class, 'show'])->name('book.show')->withoutMiddleware('auth');
    Route::get('/books/{book}/edit', [BookController::class, 'edit'])->name('book.edit');
    Route::put('/books/{book}', [BookController::class, 'update'])->name('book.update');
    Route::delete('/books/{book}', [BookController::class, 'destroy'])->name('book.destroy');

    Route::resource('/author', AuthorController::class)->withoutMiddlewareFor(['index', 'show'], 'auth');

    Route::resource('/category', CategoryController::class)->withoutMiddlewareFor(['index', 'show'], 'auth');

    Route::post('/logout', [AuthController::class, 'logout'])->name('auth.logout');

    Route::resource('/user', UserController::class);
    Route::get('/user/{user}/token/create', [UserController::class, 'createTokenForm'])->name('user.token.create');
    Route::post('/user/{user}/token', [UserController::class, 'createToken'])->name('user.token.store');
    Route::delete('/user/{user}/token/{token}', [UserController::class, 'deleteToken'])->name('user.token.delete');
});

Route::get('/auth', [AuthController::class, 'index'])->name('login');
Route::post('/auth', [AuthController::class, 'login'])->name('auth.login');

Route::get('/search', [SearchController::class, 'index'])->name('search.index');
Route::post('/search', [SearchController::class, 'submit'])->name('search.submit');
