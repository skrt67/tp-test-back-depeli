<?php

namespace App\Http\Controllers;

use App\Http\Requests\AuthorRequest;
use App\Models\Author;
use Illuminate\Support\Facades\Gate;

class AuthorController extends Controller
{
    public function index()
    {
        Gate::authorize('viewAny', Author::class);
        $authors = Author::with('books')->orderBy('firstname')->orderBy('lastname')->get();

        return view('author.index', ['authors' => $authors]);
    }

    public function show(Author $author)
    {
        Gate::authorize('view', $author);

        return view('author.show', ['author' => $author]);
    }

    public function create()
    {
        Gate::authorize('create', Author::class);

        return view('author.create');
    }

    public function store(AuthorRequest $request)
    {
        Gate::authorize('create', Author::class);
        $data = $request->validated();

        $author = new Author;
        $author->fill($data);
        $author->save();

        return redirect()->route('author.show', ['author' => $author]);
    }

    public function edit(Author $author)
    {
        Gate::authorize('update', $author);

        return view('author.edit', ['author' => $author]);
    }

    public function update(AuthorRequest $request, Author $author)
    {
        Gate::authorize('update', $author);
        $data = $request->validated();

        $author->fill($data);
        $author->save();

        return redirect()->route('author.show', ['author' => $author]);
    }

    public function destroy(Author $author)
    {
        Gate::authorize('delete', $author);
        $author->delete();

        return redirect()->route('author.index');
    }
}
