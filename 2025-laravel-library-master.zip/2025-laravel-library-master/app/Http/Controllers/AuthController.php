<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AuthController extends Controller
{
    public function index()
    {
        return view('auth.index');
    }

    public function login(Request $request)
    {

        $data = $request->validate([
            'email' => 'required|email',
            'password' => 'required',
        ]);

        $success = Auth::attempt($data);

        if (! $success) {
            return back()
                ->withInput(['email' => $request->input('email')])
                ->withErrors(['email' => 'Wrong credentials']);
        }

        $request->session()->regenerate();

        return redirect()->intended(route('book.index'));
    }

    public function logout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('book.index');
    }
}
