<?php

namespace App\Http\Controllers;

use App\Models\Book;
use App\Models\Category;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;

class SearchController extends Controller
{
    public function index()
    {

        $q = session('search.q');
        $author = session('search.author');
        $categories = session('search.categories');

        $q = str($q)->split('#\W+#u');
        $author = str($author)->split('#\W+#u');

        $books = Book::query()
            ->with('author')
            ->when(
                $q->isNotEmpty(),
                fn (Builder $query) => $query
                    ->where(
                        fn (Builder $query) => $q->each(
                            fn ($word) => $query
                                ->where(
                                    fn (Builder $query) => $query
                                        ->where('title', 'REGEXP', '\b'.$word.'\b')
                                        ->orWhere('description', 'REGEXP', '\b'.$word.'\b')
                                        ->orWhereHas(
                                            'author',
                                            fn (Builder $query) => $query
                                                ->where('lastname', 'REGEXP', '\b'.$word.'\b')
                                                ->orWhere('firstname', 'REGEXP', '\b'.$word.'\b')
                                        )
                                )
                        )
                    )
            )
            ->when(
                $author->isNotEmpty(),
                fn (Builder $query) => $query
                    ->where(
                        fn (Builder $query) => $author->each(
                            fn ($word) => $query
                                ->whereHas(
                                    'author',
                                    fn (Builder $query) => $query
                                        ->where('lastname', 'REGEXP', '\b'.$word.'\b')
                                        ->orWhere('firstname', 'REGEXP', '\b'.$word.'\b')
                                )
                        )
                    )
            )
            ->when(
                ! empty($categories),
                fn (Builder $query) => $query
                    ->whereHas(
                        'categories',
                        fn (Builder $query) => $query
                            ->whereIn('id', $categories)
                    )
            )
            ->get();

        return view('search.index', [
            'books' => $books,
            'categories' => Category::orderBy('label')->get(),
        ]);
    }

    public function submit(Request $request)
    {
        $data = $request->validate([
            'q' => 'nullable',
            'author' => 'nullable',
            'categories.*' => 'integer|exists:categories,id',
        ]);

        $request->session()->put('search', $data);

        return redirect()->route('search.index');
    }
}
