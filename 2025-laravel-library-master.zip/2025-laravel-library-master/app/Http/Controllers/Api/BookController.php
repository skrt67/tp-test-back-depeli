<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Book;
use Illuminate\Http\Request;

class BookController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        return Book::all();
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $data = $request->validate([
            'title' => 'required',
            'release_date' => 'required|date_format:Y-m-d',
            'description' => 'nullable',
            'author_id' => 'nullable|integer|exists:authors,id',
            'categories.*' => 'integer|exists:categories,id',
        ]);
        $book = new Book;
        $book->fill($data);
        $book->save();

        return $book;
    }

    /**
     * Display the specified resource.
     */
    public function show(Book $book)
    {
        return $book;
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Book $book)
    {
        $data = $request->validate([
            'title' => 'sometimes|required',
            'release_date' => 'sometimes|required|date_format:Y-m-d',
            'description' => 'nullable',
            'author_id' => 'nullable|integer|exists:authors,id',
            'categories.*' => 'integer|exists:categories,id',
        ]);
        $book->fill($data);
        $book->save();

        return $book;
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Book $book)
    {
        return response()->json($book->delete());
    }
}
