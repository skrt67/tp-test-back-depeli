<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Author;
use Illuminate\Http\Request;

class AuthorController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        return Author::all();
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $data = $request->validate([
            'firstname' => 'required',
            'lastname' => 'required',
            'birthdate' => 'nullable|date_format:Y-m-d',
            'bio' => 'nullable',
        ]);
        $author = new Author;
        $author->fill($data);
        $author->save();

        return $author;
    }

    /**
     * Display the specified resource.
     */
    public function show(Author $author)
    {
        return $author;
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Author $author)
    {
        $data = $request->validate([
            'firstname' => 'sometimes|required',
            'lastname' => 'sometimes|required',
            'birthdate' => 'nullable|date_format:Y-m-d',
            'bio' => 'nullable',
        ]);
        $author->fill($data);
        $author->save();

        return $author;
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Author $author)
    {
        return response()->json($author->delete());
    }
}
