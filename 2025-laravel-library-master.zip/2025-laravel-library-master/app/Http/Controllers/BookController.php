<?php

namespace App\Http\Controllers;

use App\Http\Requests\BookRequest;
use App\Models\Author;
use App\Models\Book;
use App\Models\Category;
use Illuminate\Support\Facades\Gate;

class BookController extends Controller
{
    public function index()
    {
        Gate::authorize('viewAny', Book::class);

        $books = Book::orderBy('title')->with('author')->get();

        return view('book.index', ['books' => $books]);
    }

    public function show(Book $book)
    {
        Gate::authorize('view', $book);

        return view('book.show', ['book' => $book]);
    }

    public function create()
    {
        Gate::authorize('create', Book::class);

        $authors = Author::orderBy('firstname')->orderBy('lastname')->get();
        $categories = Category::orderBy('label')->get();

        return view('book.create', ['authors' => $authors, 'categories' => $categories]);
    }

    public function store(BookRequest $request)
    {
        Gate::authorize('create', Book::class);

        $data = $request->validated();

        $book = new Book;
        $book->fill($data);
        $book->save();

        $book->categories()->attach($data['categories']);

        return redirect()->route('book.show', ['book' => $book]);
    }

    public function edit(Book $book)
    {
        Gate::authorize('update', $book);

        $authors = Author::orderBy('firstname')->orderBy('lastname')->get();
        $categories = Category::orderBy('label')->get();

        return view('book.edit', ['book' => $book, 'authors' => $authors, 'categories' => $categories]);
    }

    public function update(BookRequest $request, Book $book)
    {
        Gate::authorize('update', $book);

        $data = $request->validated();

        $book->fill($data);
        $book->save();

        $book->categories()->sync($data['categories']);

        return redirect()->route('book.show', ['book' => $book]);
    }

    public function destroy(Book $book)
    {
        Gate::authorize('delete', $book);

        $book->delete();

        return redirect()->route('book.index');
    }
}
