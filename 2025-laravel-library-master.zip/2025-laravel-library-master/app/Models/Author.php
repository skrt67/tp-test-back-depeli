<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Author extends Model
{
    use HasFactory;

    protected $fillable = [
        'firstname',
        'lastname',
        'birthdate',
        'bio',
    ];

    protected $casts = [
        'birthdate' => 'date',
    ];

    public function books()
    {
        return $this->hasMany(Book::class);
    }

    public function lastname(): Attribute
    {
        return Attribute::make(
            fn (mixed $value) => strtoupper($value)
        );
    }

    public function fullName(): Attribute
    {
        return Attribute::make(
            fn (mixed $value, array $attributes) => trim($attributes['firstname'].' '.strtoupper($attributes['lastname']))
        );
    }
}
