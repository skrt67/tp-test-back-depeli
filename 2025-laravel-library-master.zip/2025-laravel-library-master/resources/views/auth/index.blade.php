<x-layout.base title="Auth">
    <form action="{{ route('auth.login') }}" method="POST">
        @csrf
        <p>
            <input class="border" type="email" name="email" placeholder="Email" value="{{ old('email') }}">
            @error('email')
                <span class="text-red-500 block mt-1 text-sm">{{ $message }}</span>
            @enderror
        </p>
        <p><input class="border" type="password" name="password" placeholder="Password"></p>
        <p><button class="border" type="submit">Login</button></p>
    </form>
</x-layout.base>
