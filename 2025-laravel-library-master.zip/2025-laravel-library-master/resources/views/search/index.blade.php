<x-layout.base title="Search">

    <x-slot name="breadcrumb">
        <p>Home &gt; <a href="{{ route('search.index') }}">Search</a></p>
    </x-slot>

    <h1>Search</h1>

    <form action="{{ route('search.submit') }}" method="POST">
        @csrf
        <p>
            <input class="border" type="text" name="q" placeholder="keywords"
                value="{{ old('q', session('search.q')) }}">
            @error('q')
                <span class="text-red-500 block mt-1 text-sm">{{ $message }}</span>
            @enderror
        </p>
        <p>
            <input class="border" type="text" name="author" placeholder="author lastname or firstname"
                value="{{ old('author', session('search.author')) }}">
            @error('q')
                <span class="text-red-500 block mt-1 text-sm">{{ $message }}</span>
            @enderror
        </p>
        <p>
            @foreach ($categories as $category)
                <label class="block">
                    <input type="checkbox" name="categories[]" value="{{ $category->id }}"
                        @if (in_array($category->id, old('categories', session('search.categories', [])))) checked @endif>
                    {{ $category->label }}
                </label>
            @endforeach
            @error('categories.*')
                <span class="text-red-500 block mt-1 text-sm">{{ $message }}</span>
            @enderror
        </p>
        <p><button class="border" type="submit">Search</button></p>
    </form>

    @foreach ($books as $book)
        <h2>{{ $book->title }}</h2>
        <p>{{ $book->release_date->format('d/m/Y') }}</p>
        @if ($book->author)
            <p>by {{ $book->author?->fullName }}</p>
        @endif
    @endforeach

</x-layout.base>
