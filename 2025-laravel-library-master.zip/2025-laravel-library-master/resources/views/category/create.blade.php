<x-layout.base title="Create new category">

    <x-slot name="breadcrumb">
        <p>Home &gt; <a href="{{ route('category.index') }}">Categories</a> &gt; create</p>
    </x-slot>

    <h1>Create new category</h1>

    <form action="{{ route('category.store') }}" method="POST">
        @csrf
        <p>
            <input class="border" type="text" name="label" placeholder="Label" value="{{ old('label') }}">
            @error('label')
                <span class="text-red-500 block mt-1 text-sm">{{ $message }}</span>
            @enderror
        </p>
        <p><button class="border" type="submit">Save</button></p>
    </form>

</x-layout.base>
