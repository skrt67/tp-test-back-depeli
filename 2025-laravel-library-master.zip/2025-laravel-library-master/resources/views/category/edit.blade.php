<x-layout.base :title="'Edit category ' . $category->label">

    <x-slot name="breadcrumb">
        <p>Home &gt; <a href="{{ route('category.index') }}">Categories</a> &gt; <a
                href="{{ route('category.show', ['category' => $category]) }}">{{ $category->label }}</a> &gt; edit</p>
    </x-slot>

    <h1>Edit category &quot;{{ $category->label }}&quot;</h1>

    <form action="{{ route('category.update', ['category' => $category]) }}" method="POST">
        @csrf
        @method('PUT')
        <p>
            <input class="border" type="text" name="label" placeholder="Label"
                value="{{ old('label', $category->label) }}">
            @error('label')
                <span class="text-red-500 block mt-1 text-sm">{{ $message }}</span>
            @enderror
        </p>
        <p><button class="border" type="submit">Save</button></p>
    </form>

</x-layout.base>
