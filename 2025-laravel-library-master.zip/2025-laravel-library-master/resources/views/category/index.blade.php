<x-layout.base title="Categories">

    <x-slot name="breadcrumb">
        <p>Home &gt; <a href="{{ route('category.index') }}">Categories</a></p>
    </x-slot>

    <h1>Categories</h1>

    @can('create', \App\Models\Category::class)
        <p><a href="{{ route('category.create') }}">Create new category</a></p>
    @endcan

    @if ($categories->isNotEmpty())
        <ul>
            @foreach ($categories as $category)
                <li><a href="{{ route('category.show', ['category' => $category]) }}">{{ $category->label }}</a></li>
            @endforeach
        </ul>
    @endif

</x-layout.base>
