<x-layout.base :title="$category->label">

    <x-slot name="breadcrumb">
        <p>Home &gt; <a href="{{ route('category.index') }}">Categories</a> &gt; {{ $category->label }}</p>
    </x-slot>

    @can('update', $category)
        <p><a href="{{ route('category.edit', ['category' => $category]) }}">Edit</a></p>
    @endcan
    @can('delete', $category)
        <form action="{{ route('category.destroy', ['category' => $category]) }}" method="POST">
            @csrf
            @method('DELETE')
            <p>
                <button type="submit" class="text-blue-500">Delete</button>
            </p>
        </form>
    @endcan


    <h1>{{ $category->label }}</h1>

    @if ($category->books->isNotEmpty())
        <ul>
            @foreach ($category->books as $book)
                <li><a href="{{ route('book.show', ['book' => $book]) }}">{{ $book->title }}</a></li>
            @endforeach
        </ul>
    @endif


</x-layout.base>
