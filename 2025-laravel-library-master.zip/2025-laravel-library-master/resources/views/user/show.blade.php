<x-layout.base :title="$user->email">

    <x-slot name="breadcrumb">
        <p>Home &gt; <a href="{{ route('user.index') }}">Users</a> &gt; {{ $user->email }}</p>
    </x-slot>

    @can('update', $user)
        <p><a href="{{ route('user.edit', ['user' => $user]) }}">Edit</a></p>
    @endcan
    @can('delete', $user)
        <form action="{{ route('user.destroy', ['user' => $user]) }}" method="POST">
            @csrf
            @method('DELETE')
            <p>
                <button type="submit" class="text-blue-500">Delete</button>
            </p>
        </form>
    @endcan


    <h1>{{ $user->email }}</h1>

    @if (session('new-token'))
        <p>new token: {{ session('new-token') }}</p>
    @endif

    @can('tokenCreate', $user)
        <p><a href="{{ route('user.token.create', ['user' => $user]) }}">Create token</a></p>
    @endcan

    @if ($user->tokens->isNotEmpty())
        <ul>
            @foreach ($user->tokens as $token)
                <li>{{ $token->name }}
                    @can('tokenDelete', [$user, $token])
                        <form action="{{ route('user.token.delete', ['user' => $user, 'token' => $token]) }}" method="POST">
                            @csrf
                            @method('DELETE')
                            <button class="border" type="submit">Revoke</button>
                        </form>
                    @endcan
                </li>
            @endforeach
        </ul>
    @endif



</x-layout.base>
