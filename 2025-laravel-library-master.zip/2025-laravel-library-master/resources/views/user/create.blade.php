<x-layout.base title="Create new user">

    <x-slot name="breadcrumb">
        <p>Home &gt; <a href="{{ route('user.index') }}">Users</a> &gt; create</p>
    </x-slot>

    <h1>Create new user</h1>

    <form action="{{ route('user.store') }}" method="POST">
        @csrf
        <p>
            <input class="border" type="text" name="name" placeholder="Name"
                value="{{ old('name') }}">
            @error('name')
                <span class="text-red-500 block mt-1 text-sm">{{ $message }}</span>
            @enderror
        </p>
        <p>
            <input class="border" type="email" name="email" placeholder="Email"
                value="{{ old('email') }}">
            @error('email')
                <span class="text-red-500 block mt-1 text-sm">{{ $message }}</span>
            @enderror
        </p>
        <p>
            <input class="border" type="password" name="password" placeholder="Password">
            @error('password')
                <span class="text-red-500 block mt-1 text-sm">{{ $message }}</span>
            @enderror
        </p>
        <p><button class="border" type="submit">Save</button></p>
    </form>

</x-layout.base>
