<x-layout.base :title="'Edit user ' . $user->email">

    <x-slot name="breadcrumb">
        <p>Home &gt; <a href="{{ route('user.index') }}">Users</a> &gt; <a
                href="{{ route('user.show', ['user' => $user]) }}">{{ $user->email }}</a> &gt; edit</p>
    </x-slot>

    <h1>Edit user &quot;{{ $user->email }}&quot;</h1>

    <form action="{{ route('user.update', ['user' => $user]) }}" method="POST">
        @csrf
        @method('PUT')
        <p>
            <input class="border" type="text" name="name" placeholder="Name"
                value="{{ old('name', $user->name) }}">
            @error('name')
                <span class="text-red-500 block mt-1 text-sm">{{ $message }}</span>
            @enderror
        </p>
        <p>
            <input class="border" type="email" name="email" placeholder="Email"
                value="{{ old('email', $user->email) }}">
            @error('email')
                <span class="text-red-500 block mt-1 text-sm">{{ $message }}</span>
            @enderror
        </p>
        <p>
            <input class="border" type="password" name="password" placeholder="Password">
            @error('password')
                <span class="text-red-500 block mt-1 text-sm">{{ $message }}</span>
            @enderror
        </p>
        <p><button class="border" type="submit">Save</button></p>
    </form>

</x-layout.base>
