<x-layout.base>

    <x-slot name="breadcrumb">
        <p>Home &gt; <a href="{{ route('user.index') }}">Users</a> &gt; <a
                href="{{ route('user.show', ['user' => $user]) }}">{{ $user->email }}</a> &gt; create token</p>
    </x-slot>


    <form action="{{ route('user.token.store', ['user' => $user]) }}" method="POST">
        @csrf
        <p>
            <input class="border" type="text" name="name" placeholder="Token name" value="{{ old('name') }}">
            @error('name')
                <span class="text-red-500 block mt-1 text-sm">{{ $message }}</span>
            @enderror
        </p>
        <p>
            <button class="border" type="submit">Create</button>
        </p>
    </form>
</x-layout.base>
