<x-layout.base title="users">

    <x-slot name="breadcrumb">
        <p>Home &gt; <a href="{{ route('user.index') }}">Users</a></p>
    </x-slot>

    <h1>users</h1>

    @can('create', \App\Models\User::class)
        <p><a href="{{ route('user.create') }}">Create new user</a></p>
    @endcan

    @if ($users->isNotEmpty())
        <ul>
            @foreach ($users as $user)
                <li><a href="{{ route('user.show', ['user' => $user]) }}">{{ $user->email }}</a></li>
            @endforeach
        </ul>
    @endif

</x-layout.base>
