<x-layout.base :title="$author->fullName">
    <x-slot name="breadcrumb">
        <p>Home &gt; <a href="{{ route('author.index') }}">Authors</a> &gt; {{ $author->fullName }}</p>
    </x-slot>

    @can('update', $author)
        <p><a href="{{ route('author.edit', ['author' => $author]) }}">Edit</a></p>
    @endcan
    @can('delete', $author)
        <form action="{{ route('author.destroy', ['author' => $author]) }}" method="POST">
            @csrf
            @method('DELETE')
            <p>
                <button type="submit" class="text-blue-500">Delete</button>
            </p>
        </form>
    @endcan


    <h1>{{ $author->fullName }}</h1>
    <p>{{ $author->birthdate?->format('d/m/Y') }}</p>
    @if (!empty($author->bio))
        <p>{!! nl2br(e($author->bio), false) !!}</p>
    @endif
    @if ($author->books->isNotEmpty())
        <ul>
            @foreach ($author->books as $book)
                <li><a href="{{ route('book.show', ['book' => $book]) }}">{{ $book->title }}</a></li>
            @endforeach
        </ul>
    @endif
</x-layout.base>
