<x-layout.base :title="'Edit author '.$author->fullName">

    <x-slot name="breadcrumb">
        <p>Home &gt; <a href="{{ route('author.index') }}">Authors</a> &gt; <a href="{{ route('author.show', ['author' => $author]) }}">{{ $author->fullName }}</a> &gt; create</p>
    </x-slot>

    <h1>Edit author &quot;{{ $author->fullName }}&quot;</h1>

    <form action="{{ route('author.update', ['author'=>$author]) }}" method="POST">
        @csrf
        @method('PUT')
        <p>
            <input class="border" type="text" name="firstname" placeholder="Firstname" value="{{ old('firstname', $author->firstname) }}">
            @error('firstname')
                <span class="text-red-500 block mt-1 text-sm">{{ $message }}</span>
            @enderror
        </p>

        <p>
            <input class="border" type="text" name="lastname" placeholder="Lastname" value="{{ old('lastname', $author->lastname) }}">
            @error('lastname')
                <span class="text-red-500 block mt-1 text-sm">{{ $message }}</span>
            @enderror
        </p>

        <p>
            <input class="border" type="date" name="birthdate" placeholder="Birth date"
                value="{{ old('birthdate', $author->birthdate?->format('Y-m-d')) }}">
        </p>
        @error('birthdate')
            <span class="text-red-500 block mt-1 text-sm">{{ $message }}</span>
        @enderror

        <p>
            <textarea class="border" rows="5" name="bio" placeholder="Biography">{{ old('bio', $author->bio) }}</textarea>
            @error('bio')
                <span class="text-red-500 block mt-1 text-sm">{{ $message }}</span>
            @enderror
        </p>

        <p><button class="border" type="submit">Save</button></p>
    </form>
</x-layout.base>
