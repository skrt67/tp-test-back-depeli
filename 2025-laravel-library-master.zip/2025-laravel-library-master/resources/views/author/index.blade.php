<x-layout.base title="Authors">
    <x-slot name="breadcrumb">
        <p>Home &gt; <a href="{{ route('author.index') }}">Authors</a></p>
    </x-slot>

    <h1>Authors</h1>

    @can('create', \App\Models\Author::class)
        <p><a href="{{ route('author.create') }}">Create new author</a></p>
    @endcan

    @foreach ($authors as $author)
        <h2><a href="{{ route('author.show', ['author' => $author]) }}">{{ $author->fullName }}</a></h2>
        <p>{{ $author->birthdate?->format('d/m/Y') }}</p>
        @if (!empty($author->bio))
            <p>{!! nl2br(e($author->bio), false) !!}</p>
        @endif
        @if ($author->books->isNotEmpty())
            <ul>
                @foreach ($author->books as $book)
                    <li><a href="{{ route('book.show', ['book' => $book]) }}">{{ $book->title }}</a></li>
                @endforeach
            </ul>
        @endif
    @endforeach
</x-layout.base>
