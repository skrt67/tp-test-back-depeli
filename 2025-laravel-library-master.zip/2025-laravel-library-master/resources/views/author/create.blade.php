<x-layout.base title="Create new author">

    <x-slot name="breadcrumb">
        <p>Home &gt; <a href="{{ route('author.index') }}">Authors</a> &gt; create</p>
    </x-slot>

    <h1>Create new author</h1>

    <form action="{{ route('author.store') }}" method="POST">
        @csrf
        <p>
            <input class="border" type="text" name="firstname" placeholder="Firstname" value="{{ old('firstname') }}">
            @error('firstname')
                <span class="text-red-500 block mt-1 text-sm">{{ $message }}</span>
            @enderror
        </p>

        <p>
            <input class="border" type="text" name="lastname" placeholder="Lastname" value="{{ old('lastname') }}">
            @error('lastname')
                <span class="text-red-500 block mt-1 text-sm">{{ $message }}</span>
            @enderror
        </p>

        <p>
            <input class="border" type="date" name="birthdate" placeholder="Birth date"
                value="{{ old('birthdate') }}">
        </p>
        @error('birthdate')
            <span class="text-red-500 block mt-1 text-sm">{{ $message }}</span>
        @enderror

        <p>
            <textarea class="border" rows="5" name="bio" placeholder="Biography">{{ old('bio') }}</textarea>
            @error('bio')
                <span class="text-red-500 block mt-1 text-sm">{{ $message }}</span>
            @enderror
        </p>

        <p><button class="border" type="submit">Save</button></p>
    </form>
</x-layout.base>
