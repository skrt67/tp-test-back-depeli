<x-layout.base :title="'Edit book ' . $book->title">

    <x-slot name="breadcrumb">
        <p>Home &gt; <a href="{{ route('book.index') }}">Books</a> &gt; <a
                href="{{ route('book.show', ['book' => $book]) }}">{{ $book->title }}</a> &gt; edit</p>
    </x-slot>

    <h1>Edit book &quot;{{ $book->title }}&quot;</h1>

    <form action="{{ route('book.update', ['book' => $book]) }}" method="POST">
        @csrf
        @method('PUT')
        
        @include('book.form_fields')

        <p><button class="border" type="submit">Save</button></p>
    </form>
</x-layout.base>
