<x-layout.base :title="$book->title">

    <x-slot name="breadcrumb">
        <p>Home &gt; <a href="{{ route('book.index') }}">Books</a> &gt; {{ $book->title }}</p>
    </x-slot>

    @can('update', $book)
        <p><a href="{{ route('book.edit', ['book' => $book]) }}">Edit</a></p>
    @endcan
    @can('delete', $book)
        <form action="{{ route('book.destroy', ['book' => $book]) }}" method="POST">
            @csrf
            @method('DELETE')
            <p>
                <button type="submit" class="text-blue-500">Delete</button>
            </p>
        </form>
    @endcan

    <h1>{{ $book->title }}</h1>
    <p>{{ $book->release_date->format('d/m/Y') }}</p>
    @if ($book->author)
        <p>by <a href="{{ route('author.show', ['author' => $book->author]) }}">{{ $book->author?->fullName }}</a></p>
    @endif
    @if (!empty($book->description))
        <p>{!! nl2br(e($book->description), false) !!}</p>
    @endif

    @if ($book->categories->isNotEmpty())
        <ul>
            @foreach ($book->categories as $category)
                <li><a href="{{ route('category.show', ['category' => $category]) }}">{{ $category->label }}</a></li>
            @endforeach
        </ul>
    @endif

</x-layout.base>
