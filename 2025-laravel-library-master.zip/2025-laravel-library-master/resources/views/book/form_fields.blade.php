<p>
    <input class="border" type="text" name="title" placeholder="Title" value="{{ old('title', $book->title ?? null) }}">
    @error('title')
        <span class="text-red-500 block mt-1 text-sm">{{ $message }}</span>
    @enderror
</p>

<p>
    <input class="border" type="date" name="release_date" placeholder="Release date"
        value="{{ old('release_date', isset($book) ? $book->release_date?->format('Y-m-d') : null) }}">
</p>
@error('release_date')
    <span class="text-red-500 block mt-1 text-sm">{{ $message }}</span>
@enderror
<p>
    <textarea class="border" rows="5" name="description" placeholder="Description">{{ old('description', $book->description ?? null) }}</textarea>
    @error('description')
        <span class="text-red-500 block mt-1 text-sm">{{ $message }}</span>
    @enderror
</p>

<p>
    <select class="border" name="author_id">
        <option value=""></option>
        @foreach ($authors as $author)
            <option value="{{ $author->id }}" @if ($author->id == old('author_id', $book->author_id ?? null)) selected @endif>
                {{ $author->fullName }}</option>
        @endforeach
    </select>
    @error('author_id')
        <span class="text-red-500 block mt-1 text-sm">{{ $message }}</span>
    @enderror
</p>

<p>
    @foreach ($categories as $category)
        <label class="block">
            <input type="checkbox" name="categories[]" value="{{ $category->id }}"
                @if (in_array($category->id, old('categories', isset($book) ? $book->categories->pluck('id')->all() : []))) checked @endif>
            {{ $category->label }}
        </label>
    @endforeach
    @error('categories.*')
        <span class="text-red-500 block mt-1 text-sm">{{ $message }}</span>
    @enderror
</p>
