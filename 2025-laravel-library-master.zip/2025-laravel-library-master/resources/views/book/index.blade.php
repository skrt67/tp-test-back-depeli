<x-layout.base title="Books">

    <x-slot name="breadcrumb">
        <p>Home &gt; <a href="{{ route('book.index') }}">Books</a></p>
    </x-slot>

    <h1>Books</h1>

    @can('create', \App\Models\Book::class)
        <p><a href="{{ route('book.create') }}">Create new book</a></p>
    @endcan   

    @foreach ($books as $book)
        <h2><a href="{{ route('book.show', ['book' => $book]) }}">{{ $book->title }}</a></h2>
        <p>{{ $book->release_date->format('d/m/Y') }}</p>
        @if ($book->author)
            <p>by <a href="{{ route('author.show', ['author' => $book->author]) }}">{{ $book->author?->fullName }}</a></p>
        @endif        
        @if (!empty($book->description))
            <p>{!! nl2br(e($book->description), false) !!}</p>
        @endif
    @endforeach
</x-layout.base>
