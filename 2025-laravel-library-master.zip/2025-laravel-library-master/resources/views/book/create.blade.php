<x-layout.base title="Create new book">

    <x-slot name="breadcrumb">
        <p>Home &gt; <a href="{{ route('book.index') }}">Books</a> &gt; create</p>
    </x-slot>

    <h1>Create new book</h1>

    <form action="{{ route('book.store') }}" method="POST">
        @csrf

        @include('book.form_fields')

        <p><button class="border" type="submit">Save</button></p>
    </form>
</x-layout.base>
