<?php

namespace Database\Seeders;

use App\Models\Author;
use App\Models\Book;
use App\Models\Category;
use Illuminate\Database\Seeder;

class BookSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $categories = Category::all();

        Book::factory(10)
            ->recycle(Author::all())
            ->create()
            ->each(fn (Book $book) => $book->categories()->attach($categories->random(3)));
    }
}
